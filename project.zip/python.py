""
import json
import psycopg2
from datetime import datetime


def insert_annotation(conn, cursor, data):
    sql = """INSERT INTO annotations (x, y, width, height, rectanglelabels, image, created_at)
             VALUES (%s, %s, %s, %s, %s, %s, %s)"""
    cursor.execute(sql, (data['x'], data['y'], data['width'], data['height'],
                         data['rectanglelabels'], data['image'], data['created_at']))
    conn.commit()


json_file = r'C:\Users\HP\Desktop\json.json'
with open(json_file) as file:
    data = json.load(file)

try:
    conn = psycopg2.connect(
        dbname="practice",
        user="postgres",
        password="0000",
        host="127.0.0.1",
        port="5432"
    )
    cursor = conn.cursor()

    email_to_filter = "231040@astanait.edu.kz"

    for record in data:
        annotations = record.get('annotations', [])
        for annotation in annotations:
            completed_by = annotation.get('completed_by', {})
            if completed_by.get('email') == email_to_filter:
                for result in annotation.get('result', []):
                    value = result.get('value', {})
                    if 'rectanglelabels' in value:
                        rectanglelabels = value['rectanglelabels']

                        rectanglelabels_pg = "{" + ",".join(rectanglelabels) + "}"

                        data_to_insert = {
                            'x': value.get('x', 0.0),
                            'y': value.get('y', 0.0),
                            'width': value.get('width', 0.0),
                            'height': value.get('height', 0.0),
                            'rectanglelabels': rectanglelabels_pg,
                            'image': record['data']['image'],
                            'created_at': datetime.strptime(record['created_at'], '%Y-%m-%dT%H:%M:%S.%fZ'),
                        }

                        insert_annotation(conn, cursor, data_to_insert)

    print("Data insertion into PostgreSQL completed.")

except psycopg2.Error as e:
    print(f"Error connecting to PostgreSQL: {e}")
finally:
    if conn:
        cursor.close()
        conn.close()
        print("PostgreSQL connection closed.")

""