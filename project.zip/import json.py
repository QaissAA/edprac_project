import json
import os

def convert_to_yolo(data, image_width, image_height):
    # Преобразование данных в формат YOLO
    yolo_data = []
    for annotation in data:
        x = annotation['x']
        y = annotation['y']
        width = annotation['width']
        height = annotation['height']
        label = annotation['rectanglelabels']

        # Центр объекта
        x_center = x + width / 2.0
        y_center = y + height / 2.0

        # Нормализованные значения
        x_center /= image_width
        y_center /= image_height
        width /= image_width
        height /= image_height

        # В YOLO классы начинаются с 0, предположим, что у вас один класс с индексом 0
        yolo_data.append(f"0 {x_center} {y_center} {width} {height}")
    
    return yolo_data

json_file = r'C:\Users\HP\Desktop\json.json'
output_folder = r'C:\Users\HP\Desktop\yolo_annotations'

with open(json_file) as file:
    data = json.load(file)

# Пример: размеры изображения (их можно взять из метаданных изображения)
image_width = 1920
image_height = 1080

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

for record in data:
    annotations = record.get('annotations', [])
    for annotation in annotations:
        completed_by = annotation.get('completed_by', {})
        if completed_by.get('email') == "231040@astanait.edu.kz":
            for result in annotation.get('result', []):
                value = result.get('value', {})
                if 'rectanglelabels' in value:
                    # Конвертация данных в YOLO формат
                    yolo_data = convert_to_yolo([{
                        'x': value.get('x', 0.0),
                        'y': value.get('y', 0.0),
                        'width': value.get('width', 0.0),
                        'height': value.get('height', 0.0),
                        'rectanglelabels': value.get('rectanglelabels', [])[0]
                    }], image_width, image_height)

                    # Запись в файл
                    image_filename = os.path.splitext(os.path.basename(record['data']['image']))[0]
                    yolo_filename = os.path.join(output_folder, f"{image_filename}.txt")
                    
                    with open(yolo_filename, 'w') as yolo_file:
                        yolo_file.write("\n".join(yolo_data))

print("Data conversion to YOLO format completed.")
